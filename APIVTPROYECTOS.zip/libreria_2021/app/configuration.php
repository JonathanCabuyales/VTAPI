<?php

 // Configura path host
    define('HOST', 'http://localhost/vt/APIVTPROYECTOS/libreria_2021');
       


